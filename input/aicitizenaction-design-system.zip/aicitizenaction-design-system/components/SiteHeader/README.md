# SiteHeader

The site bar: logo lockup on the left, the main nav beside it, one quiet utility link ("Your Privacy") pinned right.

**Consumer provides:** `logoSrc` (the `aicitizenaction-lockup.png` asset), `items` (`{label, href, active}`; exactly one active), and an optional `utility` link. Height is `header-height` on `surface` with a `line` rule beneath.

The active item is `nav` at 600 with a 3px `teal` underline flush with the rule; others are `ink` at 500. Keep to four or five nav items, sentence or title case as in "Take Action", "FAQs". The utility link is `teal` with the `lock` icon and is always about the person's own safety or privacy.
