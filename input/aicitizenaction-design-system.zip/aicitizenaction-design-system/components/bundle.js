/* @ds-bundle: {"format":4,"namespace":"ACA","components":[{"name":"Icon"},{"name":"IconDisc"},{"name":"ActionCard"},{"name":"SiteHeader"},{"name":"StepMeta"},{"name":"ReassuranceNote"}]} */
(function () {
  var React = window.React, h = React.createElement;
  var ICONS = {
    'document': { d: 'M6 2h8l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zM8 10.6v1.6h8v-1.6zm0 3.4v1.6h8V14zm0 3.4V19h6v-1.6z', rule: 'evenodd' },
    'shield-search': { d: 'M12 2.6l7.4 2.9v5.6c0 4.5-3 8.3-7.4 10.1-4.4-1.8-7.4-5.6-7.4-10.1V5.5zM12.6 9.2a2.8 2.8 0 1 0 0 5.6 2.8 2.8 0 0 0 0-5.6zM14.7 14.1l3.4 3.4', stroke: true },
    'robot': { d: 'M11 2h2v3h4a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3h4zM9 9.6a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2zm6 0a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2zM9 15.2v1.4h6v-1.4zM1.5 10h1.8v5H1.5zm19.2 0h1.8v5h-1.8z', rule: 'evenodd' },
    'megaphone': { d: 'M3 9h3.6L16 3.6v16.8L6.6 15H6l1.2 5.2H4.9L3.6 15H3a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1zm15 .2a2.8 2.8 0 0 1 0 5.6z' },
    'people': { d: 'M12 3a2.6 2.6 0 1 1 0 5.2A2.6 2.6 0 0 1 12 3zM5.6 5.4a2.1 2.1 0 1 1 0 4.2 2.1 2.1 0 0 1 0-4.2zm12.8 0a2.1 2.1 0 1 1 0 4.2 2.1 2.1 0 0 1 0-4.2zM8 13.2a4 4 0 0 1 8 0V20H8zM1.4 14.2a3.1 3.1 0 0 1 5.1-2.4V20H1.4zm21.2 0a3.1 3.1 0 0 0-5.1-2.4V20h5.1z' },
    'lock': { d: 'M7 10V7a5 5 0 0 1 10 0v3h1a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zm2 0h6V7a3 3 0 0 0-6 0zm3 3.8a1.6 1.6 0 0 0-.8 3V19h1.6v-2.2a1.6 1.6 0 0 0-.8-3z', rule: 'evenodd' },
    'shield-check': { d: 'M12 2l8 3v6c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5zm-1.1 13.7l5.7-5.7-1.4-1.4-4.3 4.3-2.1-2.1-1.4 1.4z', rule: 'evenodd' },
    'arrow-right': { d: 'M4 12h15M13.5 6.5L19 12l-5.5 5.5', stroke: true }
  };
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }

  function Icon(p) {
    var ic = ICONS[p.name] || ICONS['document'], size = p.size || 24;
    var pathProps = ic.stroke
      ? { d: ic.d, fill: 'none', stroke: 'currentColor', strokeWidth: p.strokeWidth || 1.8, strokeLinecap: 'round', strokeLinejoin: 'round' }
      : { d: ic.d, fill: 'currentColor', fillRule: ic.rule || 'nonzero' };
    return h('svg', { className: cx('aca-icon', p.className), width: size, height: size, viewBox: '0 0 24 24', 'aria-hidden': p.label ? undefined : 'true', role: p.label ? 'img' : undefined, 'aria-label': p.label }, h('path', pathProps));
  }

  function IconDisc(p) {
    var tone = p.tone || 'teal', size = p.size || 76;
    return h('span', { className: cx('aca-disc', 'aca-disc-' + tone, p.className), style: { width: size, height: size } },
      h(Icon, { name: p.icon, size: Math.round(size * 0.46), strokeWidth: 2 }));
  }

  function ActionCard(p) {
    var tone = p.tone || 'teal';
    var Tag = p.href ? 'a' : 'button';
    var props = { className: cx('aca-card', tone === 'coral' ? 'aca-card-warm' : 'aca-card-cool', p.className), onClick: p.onClick };
    if (p.href) props.href = p.href; else props.type = 'button';
    return h(Tag, props,
      h(IconDisc, { icon: p.icon, tone: tone }),
      h('span', { className: 'aca-card-text' },
        h('span', { className: 'aca-card-title' }, p.title),
        p.description ? h('span', { className: 'aca-card-desc' }, p.description) : null),
      h(Icon, { name: 'arrow-right', size: 26, className: 'aca-card-arrow' }));
  }

  function SiteHeader(p) {
    var items = p.items || [];
    return h('header', { className: 'aca-header' },
      h('a', { className: 'aca-header-logo', href: p.homeHref || '#' },
        p.logoSrc ? h('img', { src: p.logoSrc, alt: p.siteName || 'AICitizenAction.org', height: p.logoHeight || 44 }) : h('span', { className: 'aca-header-name' }, p.siteName || 'AICitizenAction.org')),
      h('nav', { className: 'aca-header-nav', 'aria-label': 'Main' },
        items.map(function (it, i) {
          return h('a', { key: i, href: it.href || '#', className: cx('aca-nav-link', it.active && 'is-active'), 'aria-current': it.active ? 'page' : undefined }, it.label);
        })),
      p.utility ? h('a', { className: 'aca-header-utility', href: p.utility.href || '#' }, h(Icon, { name: 'lock', size: 18 }), p.utility.label) : null);
  }

  function StepMeta(p) {
    var n = p.steps || 3, discs = [];
    for (var i = 1; i <= n; i++) {
      if (i > 1) discs.push(h('span', { key: 'l' + i, className: 'aca-step-line' }));
      discs.push(h('span', { key: 'd' + i, className: cx('aca-step-disc', p.current && i > p.current && 'is-future') }, i));
    }
    var facts = p.facts || [];
    return h('div', { className: 'aca-steps' },
      h('span', { className: 'aca-step-discs', 'aria-hidden': 'true' }, discs),
      h('span', { className: 'aca-step-facts' }, facts.map(function (f, i) {
        return h(React.Fragment, { key: i }, i ? h('span', { className: 'aca-step-dot', 'aria-hidden': 'true' }, '\u00b7') : null, h('span', null, f));
      })));
  }

  function ReassuranceNote(p) {
    return h('p', { className: 'aca-reassure', role: 'note' },
      h(Icon, { name: 'shield-check', size: 30, className: 'aca-reassure-icon' }),
      h('span', { className: 'aca-reassure-rule', 'aria-hidden': 'true' }),
      h('span', { className: 'aca-reassure-text' }, p.lead ? h('strong', null, p.lead) : null, p.lead && p.children ? ' ' : null, p.children));
  }

  window.ACA = Object.assign(window.ACA || {}, { Icon: Icon, IconDisc: IconDisc, ActionCard: ActionCard, SiteHeader: SiteHeader, StepMeta: StepMeta, ReassuranceNote: ReassuranceNote, iconNames: Object.keys(ICONS) });
})();
