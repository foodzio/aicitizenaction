import type * as React from 'react';
export type IconName = 'document' | 'shield-search' | 'robot' | 'megaphone' | 'people' | 'lock' | 'shield-check' | 'arrow-right';
export type Tone = 'teal' | 'mist' | 'sage' | 'coral';
/** A 24-grid glyph drawn in currentColor. Pass `label` only when the icon stands alone and carries meaning. */
export interface IconProps { name: IconName; size?: number; strokeWidth?: number; label?: string; className?: string }
export declare function Icon(props: IconProps): React.ReactElement;
/** A round tinted disc holding one Icon. */
export interface IconDiscProps { icon: IconName; tone?: Tone; size?: number; className?: string }
export declare function IconDisc(props: IconDiscProps): React.ReactElement;
/** One outcome the person can choose. Renders an <a> with href, else a <button>. Coral tone switches the card to the warm surface. */
export interface ActionCardProps { title: React.ReactNode; description?: React.ReactNode; icon: IconName; tone?: Tone; href?: string; onClick?: React.MouseEventHandler; className?: string }
export declare function ActionCard(props: ActionCardProps): React.ReactElement;
/** The site bar: logo, main nav, one utility link on the right. */
export interface SiteHeaderProps { logoSrc?: string; logoHeight?: number; siteName?: string; homeHref?: string; items?: { label: string; href?: string; active?: boolean }[]; utility?: { label: string; href?: string } }
export declare function SiteHeader(props: SiteHeaderProps): React.ReactElement;
/** Numbered step discs plus short facts about the journey. `current` greys out later steps. */
export interface StepMetaProps { steps?: number; current?: number; facts?: string[] }
export declare function StepMeta(props: StepMetaProps): React.ReactElement;
/** A pill-shaped privacy or safety promise. `lead` is set bold. */
export interface ReassuranceNoteProps { lead?: React.ReactNode; children?: React.ReactNode }
export declare function ReassuranceNote(props: ReassuranceNoteProps): React.ReactElement;
declare global { interface Window { ACA: { Icon: typeof Icon; IconDisc: typeof IconDisc; ActionCard: typeof ActionCard; SiteHeader: typeof SiteHeader; StepMeta: typeof StepMeta; ReassuranceNote: typeof ReassuranceNote; iconNames: IconName[] } } }
