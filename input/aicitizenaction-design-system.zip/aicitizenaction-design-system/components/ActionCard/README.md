# ActionCard

The core choice on the Take Action page: one outcome the person wants, as a full-width clickable card with an icon disc, title, one-line description and a teal arrow.

**Consumer provides:** `title` (the outcome, in the person's own words — "An AI company fixes something I saw", not "Report to a company"), an optional `description` saying who it is for or what happens, an `icon`, a `tone`, and `href` (renders a link) or `onClick` (renders a button).

**Tones.** `teal` and `mist` for routes into institutions (laws, consultations, companies); `sage` for confidential routes; `coral` for routes rooted in people — harm that happened, joining others. Coral cards sit on `surface-warm` with `line-warm`; the others on `surface-cool` with `line-cool`. Alternate warm and cool across the grid so no two coral cards touch.

**Layout.** Two columns in a `content-max` grid, `space-4` between rows and `space-5` between columns; one column below ~720px. Every card in a row shares a height.

Do: keep titles to two lines at `card-title`, descriptions to two lines. Don't: add badges, counts or urgency; nest buttons inside; use more than eight cards on one screen.
