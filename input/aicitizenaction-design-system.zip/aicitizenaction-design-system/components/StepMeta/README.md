# StepMeta

A one-line promise of how long the journey is: numbered teal discs joined by hairlines, then short facts separated by middle dots.

**Consumer provides:** `steps` (count), optional `current` (later discs turn `teal-soft`), and `facts` — two or three plain phrases, lowercase after the first, e.g. "Three steps · about fifteen minutes · you leave with a message ready to send". Place it under the lead, `space-8` above and `space-10` before the cards. Text is `teal` in `body`.
