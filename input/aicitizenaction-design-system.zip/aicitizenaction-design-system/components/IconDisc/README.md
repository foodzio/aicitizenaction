# IconDisc

A round tinted disc holding one filled glyph; it gives each route a recognisable face without illustration.

**Consumer provides:** `icon` (one of `ACA.iconNames`), `tone` (`teal`, `mist`, `sage`, `coral`), optional `size` (default `disc-lg`, 76px; the glyph scales to 46%).

Glyphs are `teal-deep` on teal, mist and sage discs, `coral` on coral discs. The disc is decorative: always pair it with a text title. Don't put two discs of the same tone side by side in a grid if another tone fits.
