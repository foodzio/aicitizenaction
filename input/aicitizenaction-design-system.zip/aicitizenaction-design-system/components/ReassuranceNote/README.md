# ReassuranceNote

A centred pill that states a privacy or safety promise in plain words, closing the page below the cards.

**Consumer provides:** `lead` (the promise, set bold) and `children` (the detail). One per screen, centred, `space-6` below the grid. Only state what is literally true of the product: "Nobody will sign you up to anything, and nothing you type leaves your device." Never use it for marketing claims.
