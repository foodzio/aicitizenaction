# Icon

The eight-glyph set drawn on a 24px grid in `currentColor`: `document`, `shield-search`, `robot`, `megaphone`, `people`, `lock`, `shield-check`, `arrow-right`.

**Consumer provides:** `name`, optional `size` and `label`. Icons are hidden from assistive tech unless you pass `label`; give one only when the icon stands alone and carries meaning. Set colour on the parent (`teal`, `teal-deep`, `coral`). These glyphs are redrawn to match the screenshot's filled, rounded style — not the original icon files.
