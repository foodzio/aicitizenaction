AICitizenAction.org helps ordinary people turn a worry about AI into one concrete action — a message to lawmakers, a report to a company, a consultation response — in about fifteen minutes. The design is calm, warm and plain-spoken: a big question, big reassuring text, and a handful of clearly labelled routes. Nothing about it should feel like a campaign, a petition funnel or a tech product.

## Content fundamentals

- Speak to the person as "you"; let them answer in the first person. Card titles are the outcome they want, written as they would say it: "An AI company fixes something I saw", "My view is on the public record", "I know something from the inside".
- Reassure before asking. Lead with why they are qualified ("You don't need to be an expert. Your view counts because you live with the results — not because you can evaluate the technology.") and what it costs them ("Three steps · about fifteen minutes · you leave with a message ready to send").
- Plain words, short sentences, no jargon ("the people who write AI laws", not "legislators" or "policymakers"). British spelling ("organisation"). Sentence case for everything but nav items.
- Promise only what is literally true, especially about privacy: "Nobody will sign you up to anything, and nothing you type leaves your device."
- No exclamation marks, no urgency ("act now"), no counters or social proof, no emoji.

## Visual foundations

- **Colour.** The page is `surface`, warm off-white. Text is `ink` (deep navy) and `ink-muted`. `teal` is the only action colour: arrows, the active nav underline, step discs, links. Coral (`coral`, `coral-soft`) is the human, warm note — harm, people, the logo's heads — and never means error or danger. Cool cards (`surface-cool`, `line-cool`) and warm cards (`surface-warm`, `line-warm`) alternate so the grid reads as a gentle checkerboard.
- **Type.** One rounded humanist sans (`sans`). `display` for the page's single question, `lead` for the reassurance beneath it, `card-title` and `body` inside cards, `nav` and `note` for chrome. Headlines are heavy (800); everything else stays at 400–600.
- **Spacing.** 4px base. Generous above and around the question (`space-14`, `space-8`), compact inside cards (`space-6` padding, `space-2` title to description), `space-4`/`space-5` between cards. Content sits in a `content-max` column, left-aligned with the question.
- **Shape.** Cards are nearly square (`radius-card`), icon and step discs fully round (`radius-full`), the one reassurance banner a soft pill (`radius-pill`). Borders are 1px and quiet.
- **Elevation.** Flat. No shadows on cards; hover shifts the border to `teal` and nudges the arrow 3px right.
- **Focus.** Every interactive element shows `focus-ring`: a 2px page-colour gap, then 2px solid teal, 3:1+ on every surface in both themes.
- **Imagery.** None beyond icon discs and the logo. No photos, illustrations, gradients or robots-with-glowing-eyes AI clichés.
- **Themes.** `light` is the source; `dark` is a derived companion (navy ground, the same hues lifted for contrast) — treat it as a proposal.

## Iconography

Filled, rounded glyphs on a 24px grid, one per icon disc, in `teal-deep` (or `coral` on coral discs); the thin `arrow-right` and outlined `shield-search` are the only stroked glyphs. The eight-glyph set lives in the bundle as `ACA.Icon` (`ACA.iconNames`). These are redrawn to match the screenshot's style, not the site's original icon files — swap in the originals when available. Icons never stand alone as the only label.

## Known contrast exception

`coral` on `coral-soft` measures 2.8:1 in the light theme, just below the 3:1 floor for meaningful icons. It is kept exact from the source; every coral disc sits beside a text title, so no meaning rests on the glyph.
